package com.project.Authentication;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuthenticationApplicationTests {

	@Test
	public void contextLoads() {
		
	}

}
