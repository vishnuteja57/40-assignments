package com.project.SportyShoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportyShoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
